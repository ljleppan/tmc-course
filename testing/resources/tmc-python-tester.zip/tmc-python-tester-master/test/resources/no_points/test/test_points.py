import unittest
from tmc import points


class TestEverything(unittest.TestCase):

    def test_new(self):
        self.assertEqual("a", "a")


if __name__ == '__main__':
    unittest.main()
