class Greeter:

    def greet(self):
        name = input("Who are you?")
        print("Hello", name)
